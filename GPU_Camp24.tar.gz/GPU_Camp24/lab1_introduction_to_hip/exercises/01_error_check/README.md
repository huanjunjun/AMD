# Find the error

Compile and run the vector addition program and use the error from the error-checking macro to decide how to fix the problem. 

To compile and run:
```
$ make

$ sbatch submit.sh
```


